# app-biblioteca-pi3
Aplicativo android desenvolvido no projeto integrador III
## Comandos utilizados na build
  `cordova create biblioteca-social br.com.bibliotecasocial "Biblioteca Social"`  
  `cd biblioteca-social & cordova platform add android`  
  `cordova build android`
